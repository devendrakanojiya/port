import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import chi2_contingency
import warnings

# Suppressing warnings
warnings.filterwarnings('ignore')

# Load dataset
df = sns.load_dataset('mpg')

# Print dataset
print(df.head())

# Describe 'horsepower' and 'model_year' columns
print(df['horsepower'].describe())
print(df['model_year'].describe())

# Create bins for 'horsepower' and 'model_year' columns
bins_hp = [0, 75, 150, 240]
df['horsepower_new'] = pd.cut(df['horsepower'], bins=bins_hp, labels=['l', 'm', 'h'])

bins_my = [69, 72, 74, 84]
df['modelyear_new'] = pd.cut(df['model_year'], bins=bins_my, labels=['t1', 't2', 't3'])

# Crosstabulation
df_chi = pd.crosstab(df['horsepower_new'], df['modelyear_new'])
print(df_chi)

# Chi-square test
chi2, p, dof, expected = chi2_contingency(df_chi)
print("Chi-square statistic:", chi2)
print("P-value:", p)
