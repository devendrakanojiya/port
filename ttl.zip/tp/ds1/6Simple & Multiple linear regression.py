import numpy as np
import pandas as pd
from sklearn.datasets import fetch_california_housing
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# Load the California housing dataset
housing = fetch_california_housing()
housing_df = pd.DataFrame(housing.data, columns=housing.feature_names)
housing_df['PRICE'] = housing.target

# Simple Linear Regression
X_simple = housing_df[['AveRooms']]
y_simple = housing_df['PRICE']
X_train_simple, X_test_simple, y_train_simple, y_test_simple = train_test_split(X_simple, y_simple, test_size=0.2, random_state=42)
model_simple = LinearRegression()
model_simple.fit(X_train_simple, y_train_simple)
y_pred_simple = model_simple.predict(X_test_simple)

# Evaluate Simple Linear Regression
mse_simple = mean_squared_error(y_test_simple, y_pred_simple)
r2_simple = r2_score(y_test_simple, y_pred_simple)

print("Simple Linear Regression:")
print("Mean Squared Error:", mse_simple)
print("R-squared:", r2_simple)
print("Intercept:", model_simple.intercept_)
print("Coefficient:", model_simple.coef_)

# Multiple Linear Regression
X_multiple = housing_df.drop('PRICE', axis=1)
y_multiple = housing_df['PRICE']
X_train_multiple, X_test_multiple, y_train_multiple, y_test_multiple = train_test_split(X_multiple, y_multiple, test_size=0.2, random_state=42)
model_multiple = LinearRegression()
model_multiple.fit(X_train_multiple, y_train_multiple)
y_pred_multiple = model_multiple.predict(X_test_multiple)

# Evaluate Multiple Linear Regression
mse_multiple = mean_squared_error(y_test_multiple, y_pred_multiple)
r2_multiple = r2_score(y_test_multiple, y_pred_multiple)

print("\nMultiple Linear Regression:")
print("Mean Squared Error:", mse_multiple)
print("R-squared:", r2_multiple)
print("Intercept:", model_multiple.intercept_)
print("Coefficients:", model_multiple.coef_)

