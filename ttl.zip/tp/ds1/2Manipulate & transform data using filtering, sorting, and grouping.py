import pandas as pd

try:
    # Load dataset
    df = pd.read_csv("D:/SEM  VI/Data Science/sample.csv")

    # Display the first few rows of the dataset
    print("First few rows of the dataset:")
    print(df.head())

    # Filtering data based on a condition
    filtered_data = df[df['Age'] > 25]
    print("\nFiltered data (Age > 25):")
    print(filtered_data.head())

    # Sorting data
    sorted_data = df.sort_values(by='Age', ascending=False)
    print("\nSorted dataset (by Age):")
    print(sorted_data.head())

    # Grouping data
    numeric_columns = df.select_dtypes(include=['int', 'float']).columns
    grouped_data = df.groupby('Gender')[numeric_columns].mean()
    print("\nMean measurements grouped by Gender:")
    print(grouped_data)

except FileNotFoundError:
    print("Error: File not found. Please check the file path.")
except KeyError as e:
    print("Error: Column '{}' not found in the dataset.".format(e))
except Exception as e:
    print("An error occurred:", e)
