import pandas as pd

# Read data from a CSV file into a DataFrame
df = pd.read_csv("D:/SEM  VI/Data Science/sample.csv")

# Display the first 10 rows of the DataFrame
print(df.head(10))

# Drop rows with missing values
print("Dataset after dropping NA values: ")
df.dropna(inplace=True)
print(df)
