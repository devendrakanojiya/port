import pandas as pd

# Read the CSV file
df = pd.read_csv("D:/SEM  VI/Data Science/sample.csv", header=None, usecols=[0, 1, 2], skiprows=1)
df.columns = ['classlabel', 'Alcohol', 'Malic Acid']

# Print the DataFrame before dropping missing values
print("DataFrame before dropping missing values:")
print(df)

# Check for missing values
missing_values = df.isnull().sum().sum()

if missing_values == 0:
    print("\nNo missing values found.")
else:
    print("\nMissing values found. Dropping them...")
    # Drop missing values
    df.dropna(inplace=True)

    # Print the DataFrame after dropping missing values
    print("\nDataFrame after dropping missing values:")
    print(df)

    # Check if the DataFrame is empty
    if df.empty:
        print("\nDataFrame is empty after dropping missing values.")
    else:
        print("\nDataFrame is not empty after dropping missing values.")
