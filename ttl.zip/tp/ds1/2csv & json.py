# Read data from a csv file
import pandas as pd
df = pd.read_csv("D:/SEM  VI/Data Science/sample.csv")
print("Our dataset ")
print(df)

# Reading data from a JSON file
import pandas as pd
data = pd.read_csv("D:\SEM  VI\Data Science\Subject_Teacher\sample.json")
print(data)
