import pandas as pd

# Assuming this is your DataFrame
df = pd.DataFrame({
    'Name': ['John', 'Alice', 'Bob', 'Emma'],
    'Age': [25, 30, 22, 28],
    'Gender': ['Male', 'Female', 'Male', 'Female'],
    'City': ['New York', 'Los Angeles', 'Chicago', 'Houston']
})

# Perform one-hot encoding on the 'Gender' column
df_encoded = pd.get_dummies(df, columns=['Gender'])

print("DataFrame after one-hot encoding:")
print(df_encoded)
