import pandas as pd

# Read data from CSV file into a DataFrame
df = pd.read_csv("D:/SEM  VI/Data Science/sample.csv")

# Check for missing values
print(df.isna().sum())

# Fill missing values with a specific value
df.fillna(0, inplace=True)

# Drop rows with missing values
df.dropna(inplace=True)

