import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans

# Create DataFrame
data = pd.DataFrame({
    'Name': ['John', 'Alice', 'Bob', 'Emma'],
    'Age': [25, 30, 22, 28],
    'Gender': ['Male', 'Female', 'Male', 'Female'],
    'City': ['New York', 'Los Angeles', 'Chicago', 'Houston']
})

# Exclude non-numeric columns before scaling
numeric_columns = ['Age']
data_numeric = data[numeric_columns]

# Scale features
scaler = MinMaxScaler()
data_scaled = scaler.fit_transform(data_numeric)

# Perform K-Means clustering
k = 2  # Number of clusters
kmeans = KMeans(n_clusters=k, random_state=42)
data['Cluster'] = kmeans.fit_predict(data_scaled)

# Display the clustered data
print("Clustered Data:")
print(data)
