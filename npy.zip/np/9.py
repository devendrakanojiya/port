# prac 9 learning to rank ranksvm rank boost 

from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

# Generate some example data
X, y = make_classification(n_samples=1000, n_features=10, n_classes=2,
    random_state=42)
    
# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2,
    random_state=42)
    
# Feature scaling
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train RankSVM model
rank_svm = SVC(kernel='linear')
rank_svm.fit(X_train_scaled, y_train)

# Evaluate model
train_accuracy = rank_svm.score(X_train_scaled, y_train)
test_accuracy = rank_svm.score(X_test_scaled, y_test)
print("Train Accuracy:", train_accuracy)
print("Test Accuracy:", test_accuracy)

#output
Train Accuracy: 0.87125
Test Accuracy: 0.83
