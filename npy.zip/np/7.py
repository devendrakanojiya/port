# prac 7 web crawling and indexing

import requests
from bs4 import BeautifulSoup
import json

def crawl_and_index(urls):
    indexed_content = []
    for url in urls:
        try:
            response = requests.get(url)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                title = soup.title.text.strip()
                body = soup.find('body').get_text().strip()
                indexed_content.append({'url': url, 'title': title, 'body': body})
            else:
                print(f"Failed to crawl {url}. Status code: {response.status_code}")
        except Exception as e:
            print(f"An error occurred while crawling {url}: {str(e)}")
# Print indexed content in JSON format
print("indexed content: ",)
print(json.dumps(indexed_content, indent=4))

if __name__ == "__main__":
urls = ["https://www.example.com"] # Add your URLs here
crawl_and_index(urls)

#OUTPUT
indexed content:
[
{
"url": "https://www.example.com",
"title": "Example Domain",
"body": "Example Domain\nThis domain is for use in illustrative examples
in documents. You may use this\n domain in literature without prior
coordination or asking for permission.\nMore information…"
}
]
