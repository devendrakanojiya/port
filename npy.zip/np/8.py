#prac 8 page rank and link analysis

import numpy as np

# Define the web graph as an adjacency matrix
adj_matrix = np.array([
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1],
    [1, 0, 0, 0]
])

# Initial PageRank scores (equal for all pages)
page_rank = np.ones(len(adj_matrix)) / len(adj_matrix)
# Damping factor
damping_factor = 0.85
# Iterate until convergence
for _ in range(100):
    new_page_rank = np.zeros(len(adj_matrix))
    for i in range(len(adj_matrix)):
        # Distribute PageRank score from incoming links
        for j in range(len(adj_matrix)):
            if adj_matrix[j, i] > 0:
                new_page_rank[i] += damping_factor * page_rank[j] / np.
sum(adj_matrix[j])

    # Normalize PageRank scores
    page_rank = new_page_rank / np.sum(new_page_rank)
# Print the final PageRank scores
print("PageRank Scores:")
for i, score in enumerate(page_rank):
    print(f"Page {i+1}: {score:.4f}")

#output
PageRank Scores:
Page 1: 0.2500
Page 2: 0.2500
Page 3: 0.2500
Page 4: 0.2500
