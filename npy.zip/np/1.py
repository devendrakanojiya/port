#1 Practical 1 Aim : Document Indexing and Retrieval
import re
from collections import defaultdict
class InvertedIndex:
    def __init__(self):
        self.index = defaultdict(list)
        
    def add_document(self, doc_id, text):
        words = self.tokenize(text)
        for word in words:
            if doc_id not in self.index[word]:
                self.index[word].append(doc_id)
                
    def tokenize(self, text):
        # Tokenize text using regular expression
        words = re.findall(r'\b\w+\b', text.lower())
        return words
        
    def search(self, query):
        query_words = self.tokenize(query)
        result = set()
        for word in query_words:
            if word in self.index:
                result.update(self.index[word])
        return result
        
# Example usage
docs = {
    1: "This is a sample document.",
    2: "Another example document.",
    3: "A sample document for testing."
}
index = InvertedIndex()
for doc_id, doc_text in docs.items():
    index.add_document(doc_id, doc_text)
query = "Another"
results = index.search(query)
print("Matching Documents:", results)

#OUTPUT
Matching Documents: {2}
