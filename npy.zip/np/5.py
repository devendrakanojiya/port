# prac 5 Text catgorization Naive bayes SVM

from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report

# Load the 20 Newsgroups dataset
categories = ['alt.atheism', 'soc.religion.christian', 'comp.graphics', 'sci','med']
newsgroups_train = fetch_20newsgroups(subset='train', categories=categories)
newsgroups_test = fetch_20newsgroups(subset='test', categories=categories)
# Sample data from the dataset
print("Sample Document:", newsgroups_train.data[0])
print("Label:", newsgroups_train.target_names[newsgroups_train.target[0]])

Sample Document: From: sd345@city.ac.uk (Michael Collier)
Subject: Converting images to HP LaserJet III?
Nntp-Posting-Host: hampton
Organization: The City University
Lines: 14
Does anyone know of a good way (standard PC application/PD utility) to
convert tif/img/tga files into LaserJet III format. We would also like to
do the same, converting to HPGL (HP plotter) files.
Please email any response.
Is this the correct group?
Thanks in advance. Michael.
--
Michael Collier (Programmer) The Computer Unit,
Email: M.P.Collier@uk.ac.city The City University,
Tel: 071 477-8000 x3769 London,
Fax: 071 477-8565 EC1V 0HB.

Label: comp.graphics
tfidf_vectorizer = TfidfVectorizer()
X_train = tfidf_vectorizer.fit_transform(newsgroups_train.data)
X_test = tfidf_vectorizer.transform(newsgroups_test.data)
y_train = newsgroups_train.target
y_test = newsgroups_test.target

# Train Naïve Bayes classifier
nb_classifier = MultinomialNB()
nb_classifier.fit(X_train, y_train)

[9]: MultinomialNB()

# Evaluate classifiers
nb_predictions = nb_classifier.predict(X_test)
# Print classification reports
print("Naïve Bayes Classification Report:")
print(classification_report(y_test, nb_predictions,
target_names=newsgroups_test.target_names))

#output
Naïve Bayes Classification Report:
                        precision   recall  f1-score    support
alt.atheism             0.97        0.60    0.74        319
comp.graphics           0.96        0.89    0.92        389
sci.med                 0.97        0.81     0.88       396
soc.religion.christian 0.65         0.99     0.78       398

accuracy                                     0.83       1502
macro avg               0.89        0.82      0.83      1502
weighted avg            0.88        0.83      0.84      1502
